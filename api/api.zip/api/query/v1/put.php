<?php


define('MODE_DEBUG', true);

require_once 'database/config.php';
include 'database/Controller.php';

$table = $_POST['table'];
$params = json_decode($_POST['params'], true);


$dbc = new Controller($dbi);
$data = $dbc->put($table, $params);
if($data!=null){
	$data=$dbc->get_fetch($table,$params);
	echo(json_encode($data));
}

