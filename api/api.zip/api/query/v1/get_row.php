<?php
define('MODE_DEBUG',true);

require_once 'database/config.php';
include 'database/Controller.php';

$table=$_POST['table'];
$conds=json_decode($_POST['conds'],true);

$dbc=new Controller($dbi);
$data=$dbc->get_fetch($table,$conds);

echo(json_encode($data));