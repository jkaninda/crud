<?php
define('MODE_DEBUG',true);

require_once 'database/config.php';
include 'database/Controller.php';

$table=$_POST['table'];
$conds=json_decode($_POST['conds'],true);
$dbc=new Controller($dbi);
if(isset($_POST['order']))
	$data=$dbc->get($table,$conds,json_decode($_POST['order'],true));
else
	$data=$dbc->get($table,$conds);

echo(json_encode($data));