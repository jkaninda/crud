<?php
$DB_USER = "root";//Dat base user
$DB_PASS = "root"; // Date base user pass
$DB_DATABASE = "napatakwetu"; //Data base name

$dbi=['dbname'=>$DB_DATABASE,'user'=>$DB_USER,'pswd'=>$DB_PASS];
