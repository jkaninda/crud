<?php



class  Database
{
    public $con;
    private $dbname;
    private $host;
    private $user;
    private $pass;
    private $debug;

    public function __construct($dsn, $user, $pwd)
    {
        $this->debug=true;

        $this->host = $dsn['host'];
        $this->dbname = $dsn['dbname'];
        $this->pass = $pwd;
        $this->user = $user;
        $this->connect();
    }


    /*-----------------------------------------------PDO--------------------------------------------------------------------*/
   private function connect()
    {
        try {
            $this->con = new PDO("mysql:host=$this->host;dbname=$this->dbname; charset=utf8", $this->user, $this->pass);
            $this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->printException($e);
        }
    }


       public function getConnection(): PDO
    {
        return $this->con;
    }

    private function printException($e)
    {
        if ($this->debug) {
            print $e->getMessage();
        }
    }

    public
    function getDataArray($sql): array
    {
        return $this->query($sql)->fetchAll();
    }

    public
    function query($sql, $args = null)
    {
        try {
            if (isset($args)) {
                $stmt = $this->getConnection()->prepare($sql);
                return $stmt->execute($args);
            } else {
                return $this->getConnection()->query($sql);
            }
        } catch (PDOException $e) {
            $this->printException($e);

        }
        return new PDOStatement();
    }


    /*------------------------------GENERICS--------------------------------------------------------------*/
    public function get_fetch($table, $conds, $order =  array())
    {
        return $this->_get($table, $conds, $order)->fetch();

    }

    /**
     * @param $table table name from where data should be retreived
     * @param array $conds an assoc array of column=>value for matching conditions
     * @param array $order an assoc array of column=>value order
     * @return array
     */
    public
    function get($table, $conds = array(), $order = array())
    {
        return $this->_get($table, $conds, $order)->fetchAll();
    }

    public
    function _get($table, $conds = array(), $order = array())
    {
        $sql = "SELECT * FROM $table ";

        if (!empty($conds)) {
            $i = 1;
            $sql .= " WHERE ";
            foreach ($conds as $key => $val) {
                $val = str_replace("'", "''", $val);
                $sql .= $key . " = " . "'$val'";
                if (($i++) < count($conds)) {
                    $sql .= " AND ";
                }
            }
        }
        if (!empty($order)) {
            $sql .= " ORDER BY ";
            foreach ($order as $key => $val) {
                $sql .= $key . " " . $val;
                break;
            }
        }

        return $this->query($sql);

    }

    public
    function set($table, $params, $conds)
    {

        $sql = "UPDATE $table SET ";
        $args = array();
        $i = 1;
        foreach ($params as $key => $val) {
            $sql .= $key . "=:" . $i;
            $args[":" . $i] = $val;
            if (($i++) < count($params)) {
                $sql .= ",";
            }
        }
        $j = 1;
        $sql .= " WHERE ";
        foreach ($conds as $key => $val) {
            $sql .= $key . "=:" . $i;

            $args[":" . $i++] = $val;
            if (($j++) < count($conds)) {
                $sql .= " AND ";
            }
        }
        return $this->query($sql, $args);

    }

    public
    function remove($table, $conds)
    {
        // print_r($conds);

        $sql = "DELETE FROM $table ";
        $i = 1;
        $j = $i;
        $args = array();
        $sql .= " WHERE ";
        foreach ($conds as $key => $val) {
            $sql .= $key . " = :" . $i;
            $args[":" . $i++] = $val;
            if (($j++) < count($conds)) {
                $sql .= " AND ";
            }
        }
        // echo $sql;
        return $this->query($sql, $args);

    }

    public
    function put($table, $params)
    {
        // print_r($conds);
        $sql = "INSERT INTO  $table ";
        $args = array();
        $i = 1;
        $sql1 = "(";
        $sql2 = " VALUES(";

        foreach ($params as $key => $val) {
            $sql1 .= $key;
            $sql2 .= ":" . $i;
            $args[":" . $i] = $val;

            if (($i++) < count($params)) {
                $sql1 .= ",";
                $sql2 .= ",";
            } else {
                $sql1 .= ")";
                $sql2 .= ")";
                $sql .= $sql1 . $sql2;
            }
        }
        return $this->query($sql, $args);

    }


    /*-------------------------------------UTILS--------------------------------------------*/
    public
    function count($val, $table, $conds = null)
    {
        $sql = "SELECT COUNT($val) FROM $table ";
        if ($conds != null) {
            $sql .= ' WHERE ';
            $i = 1;
            foreach ($conds as $k => $v) {
                $sql .= "$k= '$v'";
                if (($i++) < count($conds)) $sql .= ' AND ';
            }
        }

        $response = $this->query($sql);
        if (is_object($response)) {
            return $data = $response->fetch()[0];
        }
        return 0;
    }

    public
    function sum($val, $table, $where)
    {
        $sql = "SELECT SUM($val)FROM $table  WHERE ";
        $i = 1;
        foreach ($where as $k => $v) {
            $sql .= "$k= '$v'";
            if (($i++) < count($where)) $sql .= ' AND ';
        }
        //echo $sql;
        return $this->query($sql)->fetch();
    }


    /*----------------------------------GETTERS-----------------------------------------------------*/

    public
    function getMax($table, $col = 'id')
    {
        $sql = "SELECT  max($col) as max_val from $table";
        $res = $this->query($sql)->fetch();

        return $res['max_val'];
    }

    public
    function getDistinct($val, $table, $conds = array(), $order = array())
    {
        $sql = "SELECT DISTINCT $val FROM $table";
        if (!empty($conds)) {
            $i = 1;
            $sql .= " WHERE ";
            foreach ($conds as $key => $val) {
                $sql .= $key . "=" . $val;
                if (($i++) < count($conds)) {
                    $sql .= " AND ";
                }
            }
        }
        if (!empty($order)) {
            $sql .= " ORDER BY ";
            foreach ($order as $key => $val) {
                $sql .= $key . " " . $val;
                break;
            }
        }
        return $this->query($sql)->fetchAll();

    }

    public function getById($table, $id)
    {
        return $this->get_fetch($table,array("id"=>$id));
    }

    /**
     * @param $elems array columns
     * @param $table $string
     * @param null $cond string = column name
     * @param null $val = value
     * @return array
     */
    public function getElements($elems, $table, $cond = null, $val = null)
    {
        $arr = array();
        $data = $this->get($table, ($cond != null) ? array($cond => $val) : null);
        foreach ($data as $d) {
            foreach ($elems as $e)
                $d[$e];
            $arr[] = $d;
        }
        return $arr;
    }

    /**
     * @param $elem string column
     * @param $table $string
     * @param null $cond string = column name
     * @param null $val = value
     * @return array
     */
    public
    function getElement($elem, $table, $cond, $val)
    {
        return $this->get_fetch($table, array($cond => $val))[$elem];
    }


    public
    function getNomByID($table, $id)
    {
        return $this->getElement("nom", $table, 'id', $id);
    }

    public
    function getNameById($table, $id)
    {
        return $this->getElement("name", $table, 'id', $id);
    }

    public
    function getElementById($elem, $table, $id)
    {
        return $this->getElement($elem, $table, 'id', $id);

    }

    public
    function getRows($table, $cond, $val)
    {
        return $this->get($table, array($cond => $val));
    }

    public
    function getRow($table, $cond, $val)
    {
        return $this->get_fetch($table, array($cond => $val));
    }

}