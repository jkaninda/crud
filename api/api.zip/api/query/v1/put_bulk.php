<?php


define('MODE_DEBUG', true);

require_once 'database/config.php';
include 'database/Controller.php';

$table = $_POST['table'];
$params = json_decode($_POST['params'], true);


$dbc = new Controller($dbi);
foreach ($params as $p) {
	$data = $dbc->put($table, $p);
}
if($data!=null){
	$data=$dbc->get_fetch($table,$p);
	echo(json_encode($data));
}