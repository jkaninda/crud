<?php
define('MODE_DEBUG', true);

require_once 'database/config.php';
include 'database/Controller.php';


$dbi = json_decode($_POST['creds'], true);
$sql = $_POST['sql'];


$dbc = new Controller($dbi);
$data = $dbc->query($sql)->fetchAll();

echo(json_encode($data));

?>
