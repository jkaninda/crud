<?php


include 'Database.php';

class Controller extends Database
{
    public function __construct($cred)
    {
        parent::__construct(array('host' => 'localhost', 'dbname' => $cred['dbname']), $cred['user'], $cred['pswd']);
    }
}